
# Key: The folder name
# Value: A list of roles that have permission to access that data

role_access_mapping = {
    "Finance": ["Finance", "C-Level"],
    "marketing": ["Marketing", "C-Level"],
    "HR": ["HR", "C-Level"],
    "engineering": ["Engineering", "C-Level"],
    "general": ["Finance", "Marketing", "HR", "Engineering", "C-Level", "General"]
}

